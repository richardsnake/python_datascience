import panda as pd
notas_mate = pd.read_csv('MATEMATICAS.csv')
notas_mate.head(20)